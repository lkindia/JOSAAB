#define DO_SEARCH_FS_LABEL 1
#define FUNC_NAME grub_search_label
#define COMMAND_NAME "search.fs_label"
#define HELP_MESSAGE N_("Search devices by label. If VARIABLE is specified, the first device found is set to a variable.")
#include "search.c"
